HPL and HAL implementation for the Maxim Analog-to-Digital Converters MAX116xx series.

NOTE: This implementation has only been tested with a MAX11615 chip but should work with other versions to.
