make surf osian dco,16 install \
 && python pppd.py
